# New Life City Online — không dùng Supabase

Bản chơi online gồm **Node.js ≥ 22.13**, **SQLite** (tích hợp trong Node 22) và HTML/CSS/JS. Không cần npm install, không có API key, không cần Supabase.

## Chạy thử trên máy tính

```bash
npm start
```

Mở `http://localhost:3000`. Tạo ba tài khoản khác nhau: buyer, seller, shipper. Người bán đăng sản phẩm, người mua mua, seller đóng gói, shipper nhận và giao. Chat theo đơn hàng.

## Đưa lên Internet

Bạn cần hosting chạy **Node.js liên tục** và có **ổ đĩa lưu dữ liệu bền vững**. Tải toàn bộ dự án lên GitHub. Tại hosting Node.js, đặt:

- Lệnh chạy: `npm start`
- Node: 22.13 hoặc mới hơn
- `NODE_ENV=production`
- `DB_PATH=/duong-dan-o-dia-luu-ben-vung/new-life-city.sqlite` (phải thay bằng đường dẫn persistent disk được hosting cung cấp)
- Nếu dùng custom domain/reverse proxy và gặp lỗi Origin, đặt `PUBLIC_ORIGIN=https://ten-mien-cua-ban`.

Dịch vụ không có persistent disk sẽ **mất dữ liệu SQLite khi tái triển khai/khởi động lại**. Không nên dùng GitHub Pages để chạy `server.js`: GitHub Pages chỉ chạy tệp tĩnh. Nên truy cập trang cùng tên miền với API (`/api`).

## Lưu ý vận hành

Đây là MVP thử nghiệm, không phải hệ thống thanh toán tiền thật. Mỗi người mới được cấp **100.000 NL$ ảo**. Mỗi đơn có phí vận chuyển **30 NL$**. Tiền bị trừ khi đặt; cộng cho seller + shipper khi giao thành công; hoàn tiền khi hủy trước đóng gói. Mọi bước tiền/đơn hàng thực hiện trong giao dịch SQLite. Không lưu mật khẩu dạng thô: dùng `scrypt` + salt và cookie HttpOnly.

Hiện cập nhật dữ liệu bằng polling 3,5 giây, không phải WebSocket. Chưa có email khôi phục mật khẩu, chống spam nâng cao, giỏ nhiều sản phẩm, hình ảnh hay trang quản trị. Phục vụ một tiến trình Node trên một SQLite file; cần nâng cấp hạ tầng khi có lượng truy cập lớn.
