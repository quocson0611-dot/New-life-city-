'use strict';
const $=id=>document.getElementById(id);let state=null,chatOrder=null,tick=null;
const money=n=>new Intl.NumberFormat('vi-VN').format(n||0)+' NL$';
function say(t){$('notice').textContent=t}
async function api(route,method='GET',data){let res;try{res=await fetch('/api'+route,{method,credentials:'same-origin',headers:method==='GET'?{}:{'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined})}catch{throw Error('Không kết nối được máy chủ. Kiểm tra Internet hoặc địa chỉ website.')}
 const result=await res.json().catch(()=>({}));if(!res.ok)throw Error(result.error||'Lỗi máy chủ '+res.status);return result}
async function action(task){try{await task()}catch(e){say('⚠️ '+e.message)}}
function elem(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=String(text);return n}
function btn(text,click,secondary=false){const b=elem('button',secondary?'secondary':'',text);b.addEventListener('click',()=>action(click));return b}
function mount(target,items){const el=$(target);el.replaceChildren(...(items.length?items:[elem('p','muted','Chưa có dữ liệu.')]))}
function orderCard(o){const card=elem('div','order');const row=elem('div','row');row.append(elem('strong','',o.product_name+' × '+o.quantity),elem('span','status',state.statuses[o.status]||o.status));card.append(row,elem('p','muted','Mã: '+o.id.slice(0,8)+' · '+money(o.total)+' + phí giao '+money(o.delivery_fee)));
 const people=elem('p','muted','Người mua: '+o.buyer+' · Người bán: '+o.seller+' · Shipper: '+(o.shipper||'chưa nhận'));card.append(people);const controls=elem('div','actions');
 if(state.user.role==='seller'&&o.seller_id===state.user.id&&o.status==='pending_seller')controls.append(btn('📦 Đóng gói',()=>mutate('/orders/'+o.id+'/pack')));
 if(state.user.role==='shipper'&&o.status==='awaiting_shipper')controls.append(btn('🚚 Nhận đơn này',()=>mutate('/orders/'+o.id+'/accept')));
 if(state.user.role==='shipper'&&o.shipper_id===state.user.id&&o.status==='delivering')controls.append(btn('✅ Giao thành công',()=>mutate('/orders/'+o.id+'/deliver')));
 if(state.user.role==='buyer'&&o.buyer_id===state.user.id&&o.status==='pending_seller')controls.append(btn('Hủy đơn / Hoàn tiền',()=>mutate('/orders/'+o.id+'/cancel'),true));
 if([o.buyer_id,o.seller_id,o.shipper_id].includes(state.user.id))controls.append(btn('💬 Chat đơn hàng',()=>openChat(o.id),true));card.append(controls);return card}
async function mutate(route){await api(route,'POST',{});say('✅ Đã cập nhật đơn hàng trên máy chủ.');await refresh()}
async function refresh(){const r=await api('/state');state=r;render()}
function render(){const u=state.user;$('auth').hidden=true;$('game').hidden=false;$('userBadge').textContent=u.username;$('hello').textContent='Xin chào, '+u.username;$('balance').textContent=money(u.balance);$('job').textContent={buyer:'🛍️ Người mua',seller:'🏪 Người bán',shipper:'🚚 Shipper'}[u.role];for(const role of ['buyer','seller','shipper'])$(role).hidden=u.role!==role;
 if(u.role==='buyer'){mount('products',state.products.map(p=>{const c=elem('div','product');c.append(elem('h3','',p.name),elem('div','price',money(p.price)),elem('p','muted','Shop: '+p.seller+' · Còn '+p.stock));c.append(btn('Mua ngay',async()=>{await api('/orders','POST',{productId:p.id,quantity:1});say('✅ Đặt hàng thành công!');await refresh()}));return c}));mount('buyerOrders',state.orders.filter(o=>o.buyer_id===u.id).map(orderCard))}
 if(u.role==='seller')mount('sellerOrders',state.orders.filter(o=>o.seller_id===u.id).map(orderCard));
 if(u.role==='shipper')mount('shipperOrders',state.orders.filter(o=>o.status==='awaiting_shipper'||o.shipper_id===u.id).map(orderCard))}
function showLoggedOut(){state=null;$('auth').hidden=false;$('game').hidden=true;$('userBadge').textContent='Chưa đăng nhập';if(tick){clearInterval(tick);tick=null}}
async function start(){await refresh();if(!tick)tick=setInterval(()=>{if(document.visibilityState==='visible')refresh().catch(e=>say('⚠️ '+e.message))},3500)}
$('register').addEventListener('click',()=>action(async()=>{await api('/register','POST',{username:$('username').value.trim(),password:$('password').value,role:$('role').value});$('password').value='';say('✅ Tạo tài khoản thành công!');await start()}));
$('login').addEventListener('click',()=>action(async()=>{await api('/login','POST',{username:$('username').value.trim(),password:$('password').value});$('password').value='';say('✅ Đăng nhập thành công!');await start()}));
$('logout').addEventListener('click',()=>action(async()=>{await api('/logout','POST',{});showLoggedOut();say('Đã đăng xuất. Tiến độ vẫn được lưu trên máy chủ.')}));
$('productForm').addEventListener('submit',e=>{e.preventDefault();action(async()=>{await api('/products','POST',{name:$('pname').value.trim(),price:Number($('pprice').value),stock:Number($('pstock').value)});$('productForm').reset();say('✅ Đã đăng sản phẩm.');await refresh()})});
async function openChat(orderId){chatOrder=orderId;$('chatDialog').hidden=false;await loadChat()}
async function loadChat(){if(!chatOrder)return;const r=await api('/orders/'+chatOrder+'/messages');mount('chatMessages',r.messages.map(m=>{const d=elem('div','bubble');d.append(elem('b','',m.sender),elem('small','',m.created_at),elem('div','',m.body));return d}));$('chatMessages').scrollTop=$('chatMessages').scrollHeight}
$('closeChat').addEventListener('click',()=>{chatOrder=null;$('chatDialog').hidden=true});
$('chatForm').addEventListener('submit',e=>{e.preventDefault();action(async()=>{await api('/orders/'+chatOrder+'/messages','POST',{text:$('chatText').value});$('chatText').value='';await loadChat()})});
setInterval(()=>{if(chatOrder&&document.visibilityState==='visible')loadChat().catch(()=>{})},3500);
api('/me').then(start).catch(()=>showLoggedOut());
